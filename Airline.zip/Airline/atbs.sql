-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 12, 2021 at 10:36 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 7.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `atbs`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE `account` (
  `Username` varchar(100) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `Sec_Q` varchar(100) NOT NULL,
  `Answer` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`Username`, `Name`, `Password`, `Sec_Q`, `Answer`) VALUES
('pohchen', 'Lau Poh Chen', 'pohchen1121', 'what is your nick name?', 'PC'),
('JohnCena', 'JohnCena', 'JohnCena', 'what is your father nick name?', 'Undertaker');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_name` varchar(255) NOT NULL,
  `admin_password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_name`, `admin_password`) VALUES
('admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `book_ticket`
--

CREATE TABLE `book_ticket` (
  `Ticket_No` int(50) NOT NULL,
  `Flight_Id` int(50) NOT NULL,
  `Flight_Name` varchar(100) NOT NULL,
  `Source` varchar(100) NOT NULL,
  `Destination` varchar(100) NOT NULL,
  `Date` varchar(100) NOT NULL,
  `Arrival_Time` varchar(100) NOT NULL,
  `Departure_Time` varchar(100) NOT NULL,
  `Total_Price` int(100) NOT NULL,
  `Seats` int(100) NOT NULL,
  `Booking_date` varchar(100) NOT NULL,
  `C_Name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `book_ticket`
--

INSERT INTO `book_ticket` (`Ticket_No`, `Flight_Id`, `Flight_Name`, `Source`, `Destination`, `Date`, `Arrival_Time`, `Departure_Time`, `Total_Price`, `Seats`, `Booking_date`, `C_Name`) VALUES
(431, 921, 'AK6072', 'Sibu', 'Miri', '2021-11-21', '1000', '0900', 200, 2, '', 'abcd\r\nefg'),
(259, 458, 'AK6467', 'Sibu', 'Kuching', '2021-06-30', '1130', '1040', 79, 1, '', 'JohnCena'),
(594, 921, 'AK6072', 'Sibu', 'Miri', '2021-11-21', '1000', '0900', 100, 1, '2021-06-13', 'JohnCena'),
(289, 458, 'AK6467', 'Sibu', 'Kuching', '2021-06-30', '1130', '1040', 158, 2, '2021-06-13', 'LPC');

-- --------------------------------------------------------

--
-- Table structure for table `cancel_ticket`
--

CREATE TABLE `cancel_ticket` (
  `Ticket_No` varchar(100) NOT NULL,
  `Flight_Id` varchar(100) NOT NULL,
  `Flight_Name` varchar(100) NOT NULL,
  `Source` varchar(100) NOT NULL,
  `Destination` varchar(100) NOT NULL,
  `Departure_Date` varchar(100) NOT NULL,
  `Arrival_Time` varchar(100) NOT NULL,
  `Departure_Time` varchar(100) NOT NULL,
  `Price` int(100) NOT NULL,
  `Seats` int(100) NOT NULL,
  `C_Name` varchar(100) NOT NULL,
  `Return_Date` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cancel_ticket`
--

INSERT INTO `cancel_ticket` (`Ticket_No`, `Flight_Id`, `Flight_Name`, `Source`, `Destination`, `Departure_Date`, `Arrival_Time`, `Departure_Time`, `Price`, `Seats`, `C_Name`, `Return_Date`) VALUES
('356', '921', 'AK6072', 'Sibu', 'Miri', '2021-11-21', '1000', '0900', 100, 1, 'Lau Poh Chen', '2021-06-01'),
('379', '921', 'AK6072', 'Sibu', 'Miri', '2021-11-21', '1000', '0900', 100, 1, 'JohnCena', '2021-06-13');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `cid` varchar(100) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `Nic_No` int(100) NOT NULL,
  `Passport_Id` int(100) NOT NULL,
  `Dob` varchar(100) NOT NULL,
  `Gender` varchar(100) NOT NULL,
  `Contact` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `flight`
--

CREATE TABLE `flight` (
  `Flight_Id` int(100) NOT NULL,
  `Flight_Name` varchar(100) NOT NULL,
  `Source` varchar(100) NOT NULL,
  `Destination` varchar(100) NOT NULL,
  `Date` varchar(100) NOT NULL,
  `Arrival_Time` varchar(100) NOT NULL,
  `Departure_Time` varchar(100) NOT NULL,
  `Flight_Price` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `flight`
--

INSERT INTO `flight` (`Flight_Id`, `Flight_Name`, `Source`, `Destination`, `Date`, `Arrival_Time`, `Departure_Time`, `Flight_Price`) VALUES
(921, 'AK6072', 'Sibu', 'Miri', '2021-11-21', '1000', '0900', 100),
(458, 'AK6467', 'Sibu', 'Kuching', '2021-06-30', '1130', '1040', 79);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
